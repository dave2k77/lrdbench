from __future__ import annotations

from collections.abc import Mapping
from typing import Any, SupportsFloat, cast

from lrdbench.enums import BenchmarkMode
from lrdbench.schema import (
    BenchmarkManifest,
    EstimatorSpec,
    LeaderboardSpec,
    MetricSpec,
    SeriesRecord,
    TruthSpec,
)


class ManifestValidationError(ValueError):
    pass


_DATA_DRIVEN_ESTIMATOR_NAMES = frozenset({"MLRandomForest", "MLSVR", "MLCNN", "MLLSTM"})


def _validate_execution_block(spec: Mapping[str, Any] | None) -> None:
    ex = dict(spec or {})
    allowed = frozenset({"max_workers", "estimate_cache_dir", "cache_read", "cache_write"})
    bad = set(ex) - allowed
    if bad:
        raise ManifestValidationError(f"unknown execution block keys: {sorted(bad)}")
    if "max_workers" in ex:
        mw = ex["max_workers"]
        if isinstance(mw, bool):
            raise ManifestValidationError(
                "execution.max_workers must be an integer >= 1 (YAML booleans are not allowed here)"
            )
        if isinstance(mw, int):
            mw_i = mw
        else:
            try:
                mw_i = int(mw)
            except (TypeError, ValueError) as exc:
                raise ManifestValidationError(
                    "execution.max_workers must be an integer >= 1"
                ) from exc
        if mw_i < 1:
            raise ManifestValidationError("execution.max_workers must be an integer >= 1")
    if "estimate_cache_dir" in ex:
        raw = ex["estimate_cache_dir"]
        if not isinstance(raw, str) or not raw.strip():
            raise ManifestValidationError("execution.estimate_cache_dir must be a non-empty string")
    for key in ("cache_read", "cache_write"):
        if key in ex and not isinstance(ex[key], bool):
            raise ManifestValidationError(f"execution.{key} must be a boolean")


def validate_ratio_uncertainty(metric_names: set[str], spec: Mapping[str, Any]) -> None:
    """Reject ratio resampling by the existing scalar-mean bootstrap engine."""
    if "paired_mae_ratio" not in metric_names or not spec or spec.get("enabled") is False:
        return
    metrics = set(spec.get("metrics", ()))
    paired_metrics = set(spec.get("paired_metrics", ())) or metrics
    if (
        not metrics
        or "paired_mae_ratio" in metrics
        or (spec.get("paired") and (not paired_metrics or "paired_mae_ratio" in paired_metrics))
    ):
        raise ManifestValidationError(
            "paired_mae_ratio uncertainty requires joint resampling of paired error components; "
            "the scalar bootstrap is unsupported. Exclude it explicitly from uncertainty metrics."
        )


def _validate_uncertainty_block(spec: Mapping[str, Any] | None) -> None:
    uq = dict(spec or {})
    allowed = frozenset(
        {
            "enabled",
            "n_bootstrap",
            "ci_levels",
            "seed",
            "metrics",
            "paired",
            "paired_metrics",
        }
    )
    bad = set(uq) - allowed
    if bad:
        raise ManifestValidationError(f"unknown uncertainty block keys: {sorted(bad)}")
    if "enabled" in uq and not isinstance(uq["enabled"], bool):
        raise ManifestValidationError("uncertainty.enabled must be a boolean")
    if "n_bootstrap" in uq:
        raw = uq["n_bootstrap"]
        if isinstance(raw, bool):
            raise ManifestValidationError("uncertainty.n_bootstrap must be an integer >= 1")
        try:
            n_boot = int(raw)
        except (TypeError, ValueError) as exc:
            raise ManifestValidationError(
                "uncertainty.n_bootstrap must be an integer >= 1"
            ) from exc
        if n_boot < 1:
            raise ManifestValidationError("uncertainty.n_bootstrap must be an integer >= 1")
    if "seed" in uq:
        raw_seed = uq["seed"]
        if isinstance(raw_seed, bool):
            raise ManifestValidationError("uncertainty.seed must be an integer")
        try:
            int(raw_seed)
        except (TypeError, ValueError) as exc:
            raise ManifestValidationError("uncertainty.seed must be an integer") from exc
    if "ci_levels" in uq:
        levels = uq["ci_levels"]
        if not isinstance(levels, list) or not levels:
            raise ManifestValidationError("uncertainty.ci_levels must be a non-empty list")
        for level in levels:
            if not (0.0 < float(level) < 1.0):
                raise ManifestValidationError(
                    f"uncertainty.ci_levels values must lie in (0,1), got {level!r}"
                )
    for key in ("metrics", "paired_metrics"):
        if key in uq:
            vals = uq[key]
            if not isinstance(vals, list) or not all(isinstance(x, str) for x in vals):
                raise ManifestValidationError(f"uncertainty.{key} must be a list of strings")
    if "paired" in uq and not isinstance(uq["paired"], bool):
        raise ManifestValidationError("uncertainty.paired must be a boolean")


def _validate_preprocessing_block(spec: Mapping[str, Any] | None) -> None:
    pp = dict(spec or {})
    if not pp:
        return
    allowed = frozenset({"include_raw", "operators", "sensitivity_eps"})
    bad = set(pp) - allowed
    if bad:
        raise ManifestValidationError(f"unknown preprocessing block keys: {sorted(bad)}")
    if "include_raw" in pp and not isinstance(pp["include_raw"], bool):
        raise ManifestValidationError("preprocessing.include_raw must be a boolean")
    if "sensitivity_eps" in pp:
        try:
            eps = float(pp["sensitivity_eps"])
        except (TypeError, ValueError) as exc:
            raise ManifestValidationError("preprocessing.sensitivity_eps must be numeric") from exc
        if eps <= 0.0:
            raise ManifestValidationError("preprocessing.sensitivity_eps must be positive")
    ops = pp.get("operators")
    if ops is None:
        return
    if not isinstance(ops, list):
        raise ManifestValidationError("preprocessing.operators must be a list")
    for i, raw in enumerate(ops):
        if not isinstance(raw, Mapping):
            raise ManifestValidationError(f"preprocessing.operators[{i}] must be a mapping")
        if not isinstance(raw.get("name"), str) or not raw["name"].strip():
            raise ManifestValidationError(
                f"preprocessing.operators[{i}].name must be a non-empty string"
            )
        if "params" in raw and not isinstance(raw["params"], Mapping):
            raise ManifestValidationError(f"preprocessing.operators[{i}].params must be a mapping")


def _estimator_base_name(estimator: EstimatorSpec) -> str:
    params = dict(estimator.parameter_schema)
    return str(params.get("_base_estimator_name", estimator.name)).split("::", 1)[0]


def _validate_ml_training_block(
    spec: Mapping[str, Any] | None,
    *,
    estimators: tuple[EstimatorSpec, ...],
) -> None:
    ml_estimators = tuple(
        e for e in estimators if _estimator_base_name(e) in _DATA_DRIVEN_ESTIMATOR_NAMES
    )
    ml = dict(spec or {})
    if not ml_estimators:
        if ml:
            allowed = frozenset(
                {
                    "enabled",
                    "target_estimand",
                    "source",
                    "contamination",
                    "validation_fraction",
                }
            )
            bad = set(ml) - allowed
            if bad:
                raise ManifestValidationError(f"unknown ml_training block keys: {sorted(bad)}")
        return

    model_paths_present = all(
        bool(
            dict(e.parameter_schema).get("_trained_model_path")
            or dict(e.parameter_schema).get("model_path")
        )
        for e in ml_estimators
    )
    if model_paths_present and not ml:
        return
    if not ml:
        raise ManifestValidationError(
            "data-driven estimators require ml_training.enabled=true or explicit params.model_path"
        )

    allowed = frozenset(
        {
            "enabled",
            "target_estimand",
            "source",
            "contamination",
            "validation_fraction",
        }
    )
    bad = set(ml) - allowed
    if bad:
        raise ManifestValidationError(f"unknown ml_training block keys: {sorted(bad)}")
    if "enabled" in ml and not isinstance(ml["enabled"], bool):
        raise ManifestValidationError("ml_training.enabled must be a boolean")
    if not bool(ml.get("enabled", False)) and not model_paths_present:
        raise ManifestValidationError(
            "data-driven estimators require ml_training.enabled=true or explicit params.model_path"
        )
    target = str(ml.get("target_estimand", "hurst_scaling_proxy"))
    if target != "hurst_scaling_proxy":
        raise ManifestValidationError("ml_training.target_estimand must be hurst_scaling_proxy")
    source = ml.get("source")
    if not isinstance(source, Mapping):
        raise ManifestValidationError("ml_training.source must be a mapping")
    if source.get("type") != "generator_grid":
        raise ManifestValidationError("ml_training.source.type must be generator_grid")
    generators = source.get("generators")
    if not isinstance(generators, list) or not generators:
        raise ManifestValidationError("ml_training.source.generators must be a non-empty list")
    contamination = ml.get("contamination")
    if contamination is not None:
        if not isinstance(contamination, Mapping):
            raise ManifestValidationError("ml_training.contamination must be a mapping")
        allowed_contam = frozenset({"include_clean", "operators"})
        bad_contam = set(contamination) - allowed_contam
        if bad_contam:
            raise ManifestValidationError(
                f"unknown ml_training.contamination keys: {sorted(bad_contam)}"
            )
        if "include_clean" in contamination and not isinstance(
            contamination["include_clean"], bool
        ):
            raise ManifestValidationError("ml_training.contamination.include_clean must be boolean")
        ops = contamination.get("operators", [])
        if ops is not None and not isinstance(ops, list):
            raise ManifestValidationError("ml_training.contamination.operators must be a list")
    if "validation_fraction" in ml:
        vf = float(ml["validation_fraction"])
        if not (0.0 <= vf < 1.0):
            raise ManifestValidationError("ml_training.validation_fraction must be in [0,1)")


def truth_for(record: SeriesRecord, estimand: str) -> TruthSpec | None:
    """Return the truth on ``record`` matching ``estimand``.

    The primary ``record.truth`` is checked first, then ``additional_truths``.
    A record may carry ground truth for several estimands (e.g. Hurst, spectral
    exponent, timescale) defined on the same realisation; each estimator is
    scored against the truth for its own ``target_estimand``.
    """
    if record.truth is not None and record.truth.target_estimand == estimand:
        return record.truth
    for extra in record.additional_truths:
        if extra.target_estimand == estimand:
            return extra
    return None


def validate_truth_compatibility(estimator_spec: EstimatorSpec, record: SeriesRecord) -> None:
    if record.truth is None and not record.additional_truths:
        return
    if truth_for(record, estimator_spec.target_estimand) is None:
        declared = [record.truth.target_estimand] if record.truth is not None else []
        declared += [t.target_estimand for t in record.additional_truths]
        raise ManifestValidationError(
            f"estimator {estimator_spec.name!r} targets {estimator_spec.target_estimand!r} "
            f"but record truth targets {declared!r}"
        )


def validate_metric_admissibility(
    metric_spec: MetricSpec,
    mode: BenchmarkMode,
    record: SeriesRecord | None = None,
) -> None:
    if mode not in metric_spec.admissible_modes:
        raise ManifestValidationError(
            f"metric {metric_spec.name!r} is not admissible in mode {mode.value!r}"
        )
    if metric_spec.requires_truth and mode is BenchmarkMode.OBSERVATIONAL:
        raise ManifestValidationError(
            f"metric {metric_spec.name!r} requires truth and cannot be used in observational mode"
        )
    if metric_spec.requires_truth and record is not None and record.truth is None:
        raise ManifestValidationError(
            f"metric {metric_spec.name!r} requires truth but record {record.record_id!r} has none"
        )


def _validate_non_empty_string(value: object, *, field: str, index: int) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ManifestValidationError(
            f"observational source.series[{index}].{field} must be a non-empty string"
        )
    return value.strip()


def _validate_optional_positive_float(value: object, *, field: str, index: int) -> None:
    if value is None:
        return
    if isinstance(value, bool):
        raise ManifestValidationError(
            f"observational source.series[{index}].{field} must be positive"
        )
    try:
        numeric = float(cast("str | SupportsFloat", value))
    except (TypeError, ValueError) as exc:
        raise ManifestValidationError(
            f"observational source.series[{index}].{field} must be positive"
        ) from exc
    if numeric <= 0.0:
        raise ManifestValidationError(
            f"observational source.series[{index}].{field} must be positive"
        )


def _observational_record_id(
    *, manifest_id: str, source_type: str, block: Mapping[str, Any], index: int
) -> str:
    raw_record_id = block.get("record_id")
    if raw_record_id is not None:
        return _validate_non_empty_string(raw_record_id, field="record_id", index=index)
    if source_type == "csv_series_index":
        path = _validate_non_empty_string(block.get("path"), field="path", index=index)
        return path.rsplit("/", 1)[-1].rsplit("\\", 1)[-1].rsplit(".", 1)[0]
    return f"{manifest_id}_inline_{index}"


def _validate_observational_source(manifest: BenchmarkManifest) -> None:
    src = manifest.source_spec
    if src.get("type") == "generator_grid":
        raise ManifestValidationError(
            "observational mode cannot use synthetic generator_grid source"
        )
    allowed_obs_sources = frozenset({"csv_series_index", "inline_table"})
    st = src.get("type")
    if st not in allowed_obs_sources:
        raise ManifestValidationError(
            f"observational source.type must be one of {sorted(allowed_obs_sources)}, got {st!r}"
        )
    series = src.get("series")
    if not isinstance(series, list) or len(series) == 0:
        raise ManifestValidationError("observational source requires a non-empty series list")

    seen_record_ids: set[str] = set()
    for i, raw_block in enumerate(series):
        if not isinstance(raw_block, Mapping):
            raise ManifestValidationError(f"observational source.series[{i}] must be a mapping")
        block = dict(raw_block)
        rid = _observational_record_id(
            manifest_id=manifest.manifest_id,
            source_type=str(st),
            block=block,
            index=i,
        )
        if rid in seen_record_ids:
            raise ManifestValidationError(f"duplicate record_id {rid!r}")
        seen_record_ids.add(rid)

        if st == "csv_series_index":
            _validate_non_empty_string(block.get("path"), field="path", index=i)
            if "value_column" in block:
                _validate_non_empty_string(block.get("value_column"), field="value_column", index=i)
            if "time_column" in block:
                _validate_non_empty_string(block.get("time_column"), field="time_column", index=i)
            if "missing_policy" in block:
                policy = _validate_non_empty_string(
                    block.get("missing_policy"), field="missing_policy", index=i
                )
                if policy not in {"drop", "error"}:
                    raise ManifestValidationError(
                        "observational source.series"
                        f"[{i}].missing_policy must be one of ['drop', 'error']"
                    )
        elif st == "inline_table" and "values" not in block:
            raise ManifestValidationError(
                f"observational source.series[{i}].values is required for inline_table"
            )

        _validate_optional_positive_float(
            block.get("sampling_rate"), field="sampling_rate", index=i
        )
        if "metadata" in block and not isinstance(block["metadata"], Mapping):
            raise ManifestValidationError(
                f"observational source.series[{i}].metadata must be a mapping"
            )


def validate_manifest(manifest: BenchmarkManifest, *, strict_unknown_keys: bool = True) -> None:
    data = manifest.raw_yaml or {}
    if strict_unknown_keys:
        allowed = {
            "manifest_id",
            "name",
            "description",
            "mode",
            "source",
            "contamination",
            "segmentation",
            "preprocessing",
            "estimators",
            "metrics",
            "leaderboards",
            "report",
            "execution",
            "uncertainty",
            "ml_training",
            "seeds",
            "validation",
        }
        bad = set(data) - allowed
        if bad:
            raise ManifestValidationError(f"unknown top-level manifest keys: {sorted(bad)}")

    # MV1
    if not manifest.manifest_id or not manifest.name:
        raise ManifestValidationError("manifest_id and name are required")
    if not manifest.estimator_specs:
        raise ManifestValidationError("at least one estimator is required")
    if not manifest.metric_specs:
        raise ManifestValidationError("at least one metric is required")

    # MV2 / MV3
    if manifest.mode is BenchmarkMode.STRESS_TEST and not manifest.contamination_spec:
        raise ManifestValidationError("stress_test mode requires a non-empty contamination block")
    if manifest.mode is BenchmarkMode.STRESS_TEST:
        ops = manifest.contamination_spec.get("operators")
        if not ops:
            raise ManifestValidationError(
                "stress_test mode requires contamination.operators with at least one operator entry"
            )
    if manifest.mode is BenchmarkMode.GROUND_TRUTH and manifest.contamination_spec:
        raise ManifestValidationError(
            "ground_truth mode must not declare contamination unless explicitly permitted"
        )
    if manifest.mode is BenchmarkMode.OBSERVATIONAL and manifest.contamination_spec:
        raise ManifestValidationError(
            "observational mode must not declare a contamination block in this release"
        )

    # MV4
    if manifest.mode is BenchmarkMode.OBSERVATIONAL:
        _validate_observational_source(manifest)

    # MV5
    for e in manifest.estimator_specs:
        if not e.target_estimand:
            raise ManifestValidationError(f"estimator {e.name!r} must declare target_estimand")

    # MV5b (Phase 5 execution)
    _validate_execution_block(manifest.execution_spec)
    _validate_uncertainty_block(manifest.uncertainty_spec)
    _validate_preprocessing_block(manifest.preprocessing_spec)
    _validate_ml_training_block(
        manifest.ml_training_spec,
        estimators=manifest.estimator_specs,
    )

    # MV6
    metric_names = {x.name for x in manifest.metric_specs}
    validate_ratio_uncertainty(metric_names, manifest.uncertainty_spec)
    if "coverage_error" in metric_names and "coverage" not in metric_names:
        raise ManifestValidationError(
            "coverage_error requires a coverage metric in the metrics block"
        )
    if "coverage_collapse" in metric_names and "coverage" not in metric_names:
        raise ManifestValidationError(
            "coverage_collapse requires a coverage metric in the metrics block"
        )
    if "relative_degradation_ratio" in metric_names and "mae" not in metric_names:
        raise ManifestValidationError(
            "relative_degradation_ratio requires an mae metric in the metrics block"
        )
    for m in manifest.metric_specs:
        if m.name == "paired_mae_ratio":
            epsilon = float(m.parameters.get("denominator_epsilon", 1e-12))
            if not 0.0 <= epsilon < float("inf"):
                raise ManifestValidationError(
                    "paired_mae_ratio denominator_epsilon must be finite and nonnegative"
                )
        validate_metric_admissibility(m, manifest.mode)
        for a in m.nominal_levels:
            if not (0.0 < float(a) < 1.0):
                raise ManifestValidationError(
                    f"nominal level for metric {m.name!r} must lie in (0,1), got {a!r}"
                )

    # MV7 / MV8 leaderboards
    for lb in manifest.leaderboard_specs:
        if "signed_estimate_drift" in lb.component_metrics:
            raise ManifestValidationError(
                "signed_estimate_drift is descriptive; use absolute_estimate_drift for ranking"
            )
        if lb.mode is not manifest.mode:
            raise ManifestValidationError(
                f"leaderboard {lb.component_metrics!r} mode {lb.mode.value!r} "
                f"does not match manifest mode {manifest.mode.value!r}"
            )
        if lb.ranking_rule != "weighted_rank":
            raise ManifestValidationError(f"unsupported ranking rule: {lb.ranking_rule!r}")
        if not lb.component_metrics or len(set(lb.component_metrics)) != len(lb.component_metrics):
            raise ManifestValidationError("leaderboard components must be nonempty and unique")
        if set(lb.weights) != set(lb.component_metrics):
            raise ManifestValidationError("leaderboard weights must match the component metrics")
        if any(not (0.0 <= w <= 1.0) for w in lb.weights.values()):
            raise ManifestValidationError("leaderboard weights must be finite and nonnegative")
        if lb.tie_break_rule not in {"best_primary_metric", "none", *lb.component_metrics}:
            raise ManifestValidationError(f"unsupported tie-break rule: {lb.tie_break_rule!r}")
        wsum = sum(lb.weights.values())
        if abs(wsum - 1.0) > 1e-6:
            raise ManifestValidationError(f"leaderboard weights must sum to 1, got {wsum}")
        for comp in lb.component_metrics:
            if comp == "coverage_error":
                if "coverage" not in metric_names:
                    raise ManifestValidationError("coverage_error requires coverage metric")
                continue
            if comp not in metric_names:
                raise ManifestValidationError(
                    f"leaderboard component {comp!r} is not declared in metrics block"
                )


def estimator_spec_from_mapping(m: Mapping[str, Any]) -> EstimatorSpec:
    assumptions_raw = m.get("assumptions", ())
    if isinstance(assumptions_raw, str):
        assumptions: tuple[str, ...] = (assumptions_raw,)
    else:
        assumptions = tuple(str(x) for x in assumptions_raw)
    cites_raw = m.get("reference_citations", ())
    cites = tuple(str(x) for x in cites_raw) if cites_raw else ()
    return EstimatorSpec(
        name=str(m["name"]),
        family=str(m.get("family", "unknown")),
        target_estimand=str(m["target_estimand"]),
        assumptions=assumptions,
        supports_ci=bool(m.get("supports_ci", False)),
        supports_diagnostics=bool(m.get("supports_diagnostics", False)),
        input_requirements=dict(m.get("input_requirements", {})),
        parameter_schema=dict(m.get("params", {})),
        reference_citations=cites,
        version=m.get("version"),
    )


def leaderboard_spec_from_mapping(m: Mapping[str, Any]) -> LeaderboardSpec:
    weights = {str(k): float(v) for k, v in m["weights"].items()}
    return LeaderboardSpec(
        mode=BenchmarkMode(str(m["mode"])),
        component_metrics=tuple(str(x) for x in m["component_metrics"]),
        weights=weights,
        ranking_rule=str(m.get("ranking_rule", "weighted_rank")),
        tie_break_rule=str(m.get("tie_break_rule", "best_primary_metric")),
        name=str(m["name"]) if m.get("name") is not None else None,
    )


def report_spec_from_mapping(m: Mapping[str, Any]) -> Any:
    from lrdbench.schema import ReportSpec

    lbs_raw = m.get("leaderboards", [])
    lbs = tuple(leaderboard_spec_from_mapping(x) for x in lbs_raw)
    return ReportSpec(
        formats=tuple(str(x) for x in m.get("formats", ("html", "csv"))),
        leaderboards=lbs,
        figure_set=tuple(str(x) for x in m.get("figure_set", ())),
        table_set=tuple(str(x) for x in m.get("table_set", ())),
        include_raw_exports=bool(m.get("include_raw_exports", True)),
        include_provenance=bool(m.get("include_provenance", True)),
        include_environment=bool(m.get("include_environment", True)),
        export_root=str(m.get("export_root", "reports")),
        naming_policy=str(m.get("naming_policy", "deterministic")),
        compression_policy=m.get("compression_policy"),
    )
