from __future__ import annotations

import time
from dataclasses import replace

import numpy as np
from scipy.optimize import minimize_scalar

from lrdbench.bootstrap import bootstrap_statistic_distribution, symmetric_percentile_cis
from lrdbench.estimators._fit_utils import fit_with_block_bootstrap
from lrdbench.interfaces import BaseEstimator
from lrdbench.schema import EstimateResult, EstimatorSpec, SeriesRecord


def _as_target_estimand(value: float | None, target_estimand: str) -> float | None:
    """Map the native ARFIMA memory parameter ``d`` to the declared estimand.

    Spectral long-memory estimators natively estimate the fractional-integration
    parameter ``d``. Its stationary fractional-noise model range is ``(-1/2, 1/2)``;
    unconstrained regression estimates may fall outside that range. When a suite declares
    ``hurst_scaling_proxy`` (i.e. compares against a Hurst exponent ``H``),
    convert via the fractional-noise identity ``H = d + 1/2`` so the estimate
    is on the same scale as the ground truth. For ``long_memory_parameter``
    targets the raw ``d`` is returned unchanged. For ``spectral_exponent_beta``
    the low-frequency spectral slope ``S(f) ~ f^(-beta)`` is returned via
    ``beta = 2d`` (equivalently ``H = (beta + 1) / 2``); see
    ``tests/unit/test_estimand_triangle.py::test_beta_estimand_mapping_is_exact``.
    """
    if value is None:
        return None
    if target_estimand == "hurst_scaling_proxy":
        return float(value) + 0.5
    if target_estimand == "spectral_exponent_beta":
        return 2.0 * float(value)
    return float(value)


def _apply_taper(x: np.ndarray, taper: str | None) -> np.ndarray:
    """Apply a spectral taper to the series.

    Supported values:
    - ``None`` or ``'none'`` → no tapering (raw series).
    - ``'cosine'`` → cosine bell (Hann-type) taper that reduces spectral leakage.
    """
    if taper is not None:
        taper = taper.lower()
    if taper is None or taper == "none":
        return x
    if taper == "cosine":
        n = x.size
        w = 0.5 * (1.0 - np.cos(2.0 * np.pi * np.arange(n) / (n - 1)))
        return x * w
    raise ValueError(f"unsupported taper: {taper!r}")


def _log_periodogram_regression_d(
    x: np.ndarray, *, m: int | None = None, taper: str | None = None
) -> float | None:
    """Log-periodogram regression slope as a long-memory parameter proxy.

    With regressor log(4 sin²(lambda/2)), the fitted slope is -d, not -2d.
    The unconstrained OLS estimate is returned, including values outside the
    stationary parameter range. This core is shared by GPH and Periodogram.
    An optional ``taper`` can reduce periodogram bias from spectral leakage.
    """
    x = np.asarray(x, dtype=float)
    n = x.size
    if x.ndim != 1 or n < 64 or not np.isfinite(x).all():
        return None
    x = x - np.mean(x)
    scale = float(np.max(np.abs(x)))
    if scale == 0.0:
        return None
    x = x / scale
    x = _apply_taper(x, taper)
    x = x - np.mean(x)
    if m is None:
        m = max(2, int(n**0.5))
    m = min(m, n // 2 - 1)
    if m < 2:
        return None
    j = np.arange(1, m + 1, dtype=float)
    lam = 2.0 * np.pi * j / n
    fft = np.fft.rfft(x)
    periodogram = (np.abs(fft[1 : m + 1]) ** 2) / n
    periodogram = np.maximum(periodogram, 1e-20)
    log_freq = np.log(4.0 * np.sin(lam / 2.0) ** 2)
    log_per = np.log(periodogram)
    x_mean = float(np.mean(log_freq))
    y_mean = float(np.mean(log_per))
    denom = float(np.sum((log_freq - x_mean) ** 2))
    if denom < 1e-20:
        return None
    beta = float(np.sum((log_freq - x_mean) * (log_per - y_mean)) / denom)
    d = float(-beta)
    if not np.isfinite(d):
        return None
    return d


# Backward-compatible aliases for internal callers
def _gph_long_memory(x: np.ndarray, *, m: int | None = None) -> float | None:
    """Geweke–Porter–Hudak regression slope as a crude long-memory proxy near 0 frequency."""
    return _log_periodogram_regression_d(x, m=m, taper=None)


def _log_periodogram_slope_d(x: np.ndarray, *, m: int | None = None) -> float | None:
    """Unclipped log-periodogram regression memory estimate (GPH-type)."""
    return _log_periodogram_regression_d(x, m=m, taper=None)


class GPHEstimator(BaseEstimator):
    """Geweke–Porter–Hudak log-periodogram regression for long-memory parameter d."""

    VERSION = "0.5.0"

    def __init__(self, spec: EstimatorSpec) -> None:
        self._spec = spec

    @property
    def spec(self) -> EstimatorSpec:
        return self._spec

    def fit(self, record: SeriesRecord) -> EstimateResult:
        t0 = time.perf_counter()
        params = dict(self._spec.parameter_schema)
        n_boot = int(params.get("n_bootstrap", 200))
        block_len = int(params.get("bootstrap_block_len", 0)) or max(4, record.values.size // 10)
        levels_raw = params.get("ci_levels")
        ci_levels = tuple(float(x) for x in levels_raw) if levels_raw is not None else (0.95,)
        seed = 0
        if record.provenance is not None and record.provenance.seed is not None:
            seed = int(record.provenance.seed) + 7919
        rng = np.random.default_rng(seed & (2**32 - 1))

        try:
            taper = str(params.get("taper", "none")) or "none"
            m = int(params["m"]) if params.get("m") is not None else None
            estimand = self._spec.target_estimand
            d = _as_target_estimand(
                _log_periodogram_regression_d(record.values, m=m, taper=taper), estimand
            )
            dt = time.perf_counter() - t0
            if d is None or not np.isfinite(d):
                return EstimateResult(
                    record_id=record.record_id,
                    estimator_name=self._spec.name,
                    point=None,
                    runtime_seconds=dt,
                    valid=False,
                    failure_reason="insufficient_signal_for_gph",
                    estimator_version=self.VERSION,
                )

            def _gph_stat(z: np.ndarray) -> float | None:
                return _as_target_estimand(
                    _log_periodogram_regression_d(z, m=m, taper=taper), estimand
                )

            bootstrap_diagnostics: dict[str, object] = {}
            samples = bootstrap_statistic_distribution(
                record.values,
                rng,
                _gph_stat,
                n_boot=n_boot,
                block_len=block_len,
                diagnostics=bootstrap_diagnostics,
            )
            cis = symmetric_percentile_cis(samples, ci_levels) if samples.size >= 5 else ()
            bstd = float(np.std(samples)) if samples.size >= 2 else None
            ci_low = ci_high = None
            for a, lo, hi in cis:
                if abs(a - 0.95) < 1e-9:
                    ci_low, ci_high = lo, hi
                    break

            diag: dict[str, object] = {
                "ci_method": "circular_block_bootstrap",
                "n_bootstrap": n_boot,
                "bootstrap_block_len": block_len,
                "bootstrap_replicates_used": int(samples.size),
                "bootstrap_point_std": bstd,
                **bootstrap_diagnostics,
                "ci_available_levels": tuple(a for a, _, _ in cis),
                "ci_unavailable_reason": (
                    "disabled"
                    if n_boot == 0
                    else "insufficient_replicates"
                    if samples.size < 5
                    else "no_valid_levels"
                )
                if not cis
                else None,
                "m": m,
                "taper": taper,
                "regression_slope_multiplier": -1.0,
                "point_clipped": False,
            }
            return EstimateResult(
                record_id=record.record_id,
                estimator_name=self._spec.name,
                point=d,
                ci_low=ci_low,
                ci_high=ci_high,
                runtime_seconds=dt,
                valid=True,
                estimator_version=self.VERSION,
                diagnostics=diag,
                warnings=("bootstrap_draws_discarded",) if samples.size < n_boot else (),
                bootstrap_cis=cis,
            )
        except Exception as exc:  # noqa: BLE001
            dt = time.perf_counter() - t0
            return EstimateResult(
                record_id=record.record_id,
                estimator_name=self._spec.name,
                point=None,
                runtime_seconds=dt,
                valid=False,
                failure_reason=f"exception:{type(exc).__name__}:{exc}",
                estimator_version=self.VERSION,
            )


def _arfima_spectrum_shape(lam: np.ndarray, d: float) -> np.ndarray:
    h = np.abs(2.0 * np.sin(lam / 2.0)) ** (-2.0 * d)
    return np.maximum(h, 1e-12)


def _whittle_profile_negloglik(d: float, lam: np.ndarray, i_per: np.ndarray) -> float:
    if not -0.499 < d < 0.499:
        return 1e12
    h = _arfima_spectrum_shape(lam, d)
    sig2 = float(np.mean(i_per / h))
    if sig2 <= 0.0 or not np.isfinite(sig2):
        return 1e12
    f = sig2 * h  # i_per uses |FFT|²/n, so its profiled scale has no 2*pi divisor.
    return float(np.mean(np.log(f) + i_per / f))


def _whittle_arfima_d(x: np.ndarray, *, m: int | None = None) -> float | None:
    """Gaussian Whittle MLE for ARFIMA(0,d,0) spectral shape (fractional noise)."""
    x = np.asarray(x, dtype=float)
    n = x.size
    if n < 128:
        return None
    if x.ndim != 1 or not np.isfinite(x).all():
        return None
    x = x - np.mean(x)
    amplitude = float(np.max(np.abs(x)))
    if amplitude == 0.0:
        return None
    x = x / amplitude
    if m is None:
        m = max(8, n // 8)
    m = min(m, n // 2 - 1)
    if m < 8:
        return None
    j = np.arange(1, m + 1, dtype=float)
    lam = 2.0 * np.pi * j / n
    fft = np.fft.rfft(x)
    i_per = (np.abs(fft[1 : m + 1]) ** 2) / n
    i_per = np.maximum(i_per, 1e-20)
    res = minimize_scalar(
        _whittle_profile_negloglik,
        args=(lam, i_per),
        bounds=(-0.49, 0.49),
        method="bounded",
    )
    if not res.success or not np.isfinite(res.fun):
        return None
    return float(np.clip(res.x, -0.499, 0.499))


def _local_whittle_objective(d: float, lam: np.ndarray, i_per: np.ndarray) -> float:
    """Profile local Whittle (Robinson-type) objective R_m(d)."""
    if not -0.499 < d < 0.499:
        return 1e12
    g = float(np.mean((lam ** (2.0 * d)) * i_per))
    if g <= 0.0 or not np.isfinite(g):
        return 1e12
    return float(np.log(g) - 2.0 * d * float(np.mean(np.log(lam))))


def _modified_local_whittle_d(x: np.ndarray, *, m: int | None = None) -> float | None:
    """Modified local Whittle estimator of memory d (low-frequency band)."""
    x = np.asarray(x, dtype=float)
    n = x.size
    if n < 256:
        return None
    if x.ndim != 1 or not np.isfinite(x).all():
        return None
    x = x - np.mean(x)
    amplitude = float(np.max(np.abs(x)))
    if amplitude == 0.0:
        return None
    x = x / amplitude
    if m is None:
        m = max(8, int(n**0.55))
    m = min(m, n // 3)
    if m < 8:
        return None
    j = np.arange(1, m + 1, dtype=float)
    lam = 2.0 * np.pi * j / n
    fft = np.fft.rfft(x)
    i_per = (np.abs(fft[1 : m + 1]) ** 2) / n
    i_per = np.maximum(i_per, 1e-20)
    res = minimize_scalar(
        _local_whittle_objective,
        args=(lam, i_per),
        bounds=(-0.49, 0.49),
        method="bounded",
    )
    if not res.success or not np.isfinite(res.fun):
        return None
    return float(np.clip(res.x, -0.499, 0.499))


class PeriodogramRegressionEstimator(BaseEstimator):
    """Log-periodogram regression (memory parameter d, GPH-type)."""

    VERSION = "0.4.0"

    def __init__(self, spec: EstimatorSpec) -> None:
        self._spec = spec

    @property
    def spec(self) -> EstimatorSpec:
        return self._spec

    def fit(self, record: SeriesRecord) -> EstimateResult:
        params = dict(self._spec.parameter_schema)
        taper = str(params.get("taper", "none")) or "none"
        estimand = self._spec.target_estimand

        def stat(z: np.ndarray) -> float | None:
            m = int(params["m"]) if params.get("m") is not None else None
            return _as_target_estimand(_log_periodogram_regression_d(z, m=m, taper=taper), estimand)

        return fit_with_block_bootstrap(
            record,
            self._spec,
            statistic=stat,
            estimator_version=self.VERSION,
            failure_reason="insufficient_signal_for_periodogram",
            seed_offset=101,
        )


class PeriodogramBetaEstimator(BaseEstimator):
    """Low-frequency spectral-exponent (beta) estimator, ``S(f) ~ f^(-beta)``.

    Shares the log-periodogram regression core with GPH/Periodogram but declares
    the ``spectral_exponent_beta`` estimand, reporting ``beta = 2d`` so a suite
    can benchmark the spectral slope directly against a beta ground truth on the
    same realisation used for Hurst estimation. The default frequency count is
    the shared ``m = sqrt(n)``. Bandwidth controls the bias-variance tradeoff;
    the former factor-of-two error was an implementation defect, not bandwidth bias.
    """

    VERSION = "0.2.0"

    def __init__(self, spec: EstimatorSpec) -> None:
        self._spec = spec

    @property
    def spec(self) -> EstimatorSpec:
        return self._spec

    def fit(self, record: SeriesRecord) -> EstimateResult:
        params = dict(self._spec.parameter_schema)
        taper = str(params.get("taper", "none")) or "none"
        estimand = self._spec.target_estimand

        def stat(z: np.ndarray) -> float | None:
            m = int(params["m"]) if params.get("m") is not None else None
            return _as_target_estimand(_log_periodogram_regression_d(z, m=m, taper=taper), estimand)

        return fit_with_block_bootstrap(
            record,
            self._spec,
            statistic=stat,
            estimator_version=self.VERSION,
            failure_reason="insufficient_signal_for_periodogram",
            seed_offset=103,
        )


class WhittleMLEEstimator(BaseEstimator):
    """Gaussian Whittle likelihood for ARFIMA(0,d,0) spectral density."""

    VERSION = "0.3.0"

    def __init__(self, spec: EstimatorSpec) -> None:
        self._spec = spec

    @property
    def spec(self) -> EstimatorSpec:
        return self._spec

    def fit(self, record: SeriesRecord) -> EstimateResult:
        params = dict(self._spec.parameter_schema)
        estimand = self._spec.target_estimand

        def stat(z: np.ndarray) -> float | None:
            m = int(params["m"]) if params.get("m") is not None else None
            return _as_target_estimand(_whittle_arfima_d(z, m=m), estimand)

        result = fit_with_block_bootstrap(
            record,
            self._spec,
            statistic=stat,
            estimator_version=self.VERSION,
            failure_reason="insufficient_signal_for_whittle",
            seed_offset=203,
        )
        return _bounded_memory_diagnostics(result, estimand, "arfima_0_d_0_whittle")


class ModifiedLocalWhittleEstimator(BaseEstimator):
    """Ordinary Gaussian local Whittle, retaining the legacy registry name.

    No taper, differencing or nonstationary correction is implemented.
    """

    VERSION = "0.3.0"

    def __init__(self, spec: EstimatorSpec) -> None:
        self._spec = spec

    @property
    def spec(self) -> EstimatorSpec:
        return self._spec

    def fit(self, record: SeriesRecord) -> EstimateResult:
        params = dict(self._spec.parameter_schema)
        estimand = self._spec.target_estimand

        def stat(z: np.ndarray) -> float | None:
            m = int(params["m"]) if params.get("m") is not None else None
            return _as_target_estimand(_modified_local_whittle_d(z, m=m), estimand)

        result = fit_with_block_bootstrap(
            record,
            self._spec,
            statistic=stat,
            estimator_version=self.VERSION,
            failure_reason="insufficient_signal_for_mlw",
            seed_offset=307,
        )
        return _bounded_memory_diagnostics(result, estimand, "ordinary_local_whittle")


def _bounded_memory_diagnostics(
    result: EstimateResult, estimand: str, algorithm: str
) -> EstimateResult:
    native = result.point
    if native is not None:
        if estimand == "hurst_scaling_proxy":
            native -= 0.5
        elif estimand == "spectral_exponent_beta":
            native /= 2.0
    boundary = native is not None and min(abs(native + 0.49), abs(native - 0.49)) <= 1e-4
    return replace(
        result,
        diagnostics={
            **result.diagnostics,
            "algorithm": algorithm,
            "native_d": native,
            "optimization_bounds_d": (-0.49, 0.49),
            "optimization_boundary_hit": boundary,
            "point_clipped": False,
        },
        warnings=result.warnings + (("optimization_boundary_hit",) if boundary else ()),
    )
