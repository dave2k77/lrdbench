from __future__ import annotations

from collections import defaultdict
from collections.abc import Sequence
from dataclasses import replace
from itertools import combinations
from math import sqrt
from typing import Any

import numpy as np

from lrdbench.enums import BenchmarkMode
from lrdbench.interfaces import BaseEvaluator
from lrdbench.metrics_catalog import METRIC_SPECS
from lrdbench.paired_metrics import (
    STRESS_PAIR_METRICS,
    aggregate_paired_mae_ratio,
    stress_pair_rows,
)
from lrdbench.registries import EstimatorRegistry
from lrdbench.schema import (
    BenchmarkManifest,
    EstimateResult,
    EstimatorSpec,
    MetricBundle,
    MetricSpec,
    MetricValue,
    SeriesRecord,
)
from lrdbench.strata import stratum_from_record, stratum_key
from lrdbench.validation import (
    ManifestValidationError,
    truth_for,
    validate_metric_admissibility,
    validate_ratio_uncertainty,
    validate_truth_compatibility,
)

DISAGREEMENT_METRICS = frozenset(
    {
        "cross_estimator_dispersion",
        "pairwise_estimator_disagreement",
        "family_level_disagreement",
    }
)

SENSITIVITY_METRICS = frozenset(
    {
        "parameter_variant_sensitivity",
        "max_variant_drift",
    }
)

CORRECTION_PAIR_METRICS = frozenset(
    {
        "correction_drift",
        "correction_degradation_ratio",
        "oracle_gap",
    }
)


def _index_estimates(estimates: Sequence[EstimateResult]) -> dict[tuple[str, str], EstimateResult]:
    out: dict[tuple[str, str], EstimateResult] = {}
    for e in estimates:
        out[(e.record_id, e.estimator_name)] = e
    return out


def _ci_interval(est: EstimateResult, alpha: float) -> tuple[float, float] | None:
    if not est.valid or est.point is None or not np.isfinite(est.point):
        return None
    for a, lo, hi in est.bootstrap_cis:
        if abs(float(a) - float(alpha)) < 1e-9 and np.isfinite(lo) and np.isfinite(hi) and lo <= hi:
            return (float(lo), float(hi))
    if (
        not est.bootstrap_cis
        and est.ci_low is not None
        and est.ci_high is not None
        and np.isfinite(est.ci_low)
        and np.isfinite(est.ci_high)
        and est.ci_low <= est.ci_high
        and abs(float(alpha) - 0.95) < 1e-9
    ):
        return (float(est.ci_low), float(est.ci_high))
    return None


def _default_false_positive_threshold(target_estimand: str) -> float:
    if target_estimand == "long_memory_parameter":
        return 0.1
    return 0.6


def _default_false_positive_null_max(target_estimand: str) -> float:
    if target_estimand == "long_memory_parameter":
        return 0.0
    return 0.5


CLASSIFICATION_ESTIMANDS = frozenset({"lrd_class"})
CLASSIFICATION_METRICS = frozenset(
    {"roc_auc", "balanced_accuracy", "true_positive_rate", "false_positive_rate"}
)


def estimand_kind(target_estimand: str) -> str:
    """Classify an estimand as a decision ('classification') or scalar ('regression')."""
    return "classification" if target_estimand in CLASSIFICATION_ESTIMANDS else "regression"


def _metric_applies_per_series(ms: MetricSpec, target_estimand: str) -> bool:
    """Route a metric to an estimator by kind.

    Classification metrics are computed only in the aggregate pass
    (``_classification_rows``), never per-series. Regression truth-metrics apply
    only to scalar estimands; ``neutral`` metrics (validity_rate, runtime) apply
    to any estimand.
    """
    kind = getattr(ms, "kind", "regression")
    if kind == "classification":
        return False
    if kind == "neutral":
        return True
    return estimand_kind(target_estimand) == "regression"


def _roc_auc(scores: Sequence[float], labels: Sequence[float]) -> float | None:
    """Rank-based ROC-AUC (Mann-Whitney U), robust to ties. None if single-class."""
    pos = [s for s, y in zip(scores, labels, strict=True) if y >= 0.5]
    neg = [s for s, y in zip(scores, labels, strict=True) if y < 0.5]
    if not pos or not neg:
        return None
    order = np.argsort(np.asarray(scores, dtype=float), kind="mergesort")
    ranks = np.empty(len(scores), dtype=float)
    sorted_scores = np.asarray(scores, dtype=float)[order]
    i = 0
    n = len(scores)
    while i < n:
        j = i
        while j + 1 < n and sorted_scores[j + 1] == sorted_scores[i]:
            j += 1
        avg_rank = (i + j) / 2.0 + 1.0  # 1-based average rank for ties
        ranks[order[i : j + 1]] = avg_rank
        i = j + 1
    labels_arr = np.asarray(labels, dtype=float)
    rank_pos = float(ranks[labels_arr >= 0.5].sum())
    n_pos = len(pos)
    n_neg = len(neg)
    auc = (rank_pos - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg)
    return float(auc)


def _confusion_at_threshold(
    scores: Sequence[float], labels: Sequence[float], threshold: float
) -> tuple[float, float] | None:
    """Return (TPR, FPR) at a decision threshold; None if a class is absent."""
    pos = [(s, y) for s, y in zip(scores, labels, strict=True) if y >= 0.5]
    neg = [(s, y) for s, y in zip(scores, labels, strict=True) if y < 0.5]
    if not pos or not neg:
        return None
    tpr = float(np.mean([1.0 if s >= threshold else 0.0 for s, _ in pos]))
    fpr = float(np.mean([1.0 if s >= threshold else 0.0 for s, _ in neg]))
    return tpr, fpr


def _classification_metric_rows(
    run_id: str,
    records: Sequence[SeriesRecord],
    idx: dict[tuple[str, str], EstimateResult],
    manifest: BenchmarkManifest,
) -> list[MetricValue]:
    """Population-level classification metrics for decision (``lrd_class``) estimators.

    Threshold-free ``roc_auc`` and threshold-based balanced_accuracy / TPR / FPR are
    computed once per estimator over the full (score, label) set, emitted as
    ``balanced_global`` aggregate rows. Non-classification estimators and suites
    without classification metrics yield nothing.
    """
    class_metrics = [ms for ms in manifest.metric_specs if ms.name in CLASSIFICATION_METRICS]
    if not class_metrics:
        return []
    rows: list[MetricValue] = []
    for es in manifest.estimator_specs:
        if estimand_kind(es.target_estimand) != "classification":
            continue
        scores: list[float] = []
        labels: list[float] = []
        for rec in records:
            truth = truth_for(rec, es.target_estimand)
            if truth is None or truth.target_value is None:
                continue
            est = idx.get((rec.record_id, es.name))
            if est is None or not est.valid or est.point is None:
                continue
            scores.append(float(est.point))
            labels.append(float(truth.target_value))
        n_pos = int(sum(1 for y in labels if y >= 0.5))
        meta_base = {"n_scored": len(scores), "n_positive": n_pos}
        for ms in class_metrics:
            threshold = float(dict(ms.parameters).get("threshold", 0.5))
            value: float | None
            if ms.name == "roc_auc":
                value = _roc_auc(scores, labels) if len(scores) >= 2 else None
            else:
                conf = _confusion_at_threshold(scores, labels, threshold)
                if conf is None:
                    value = None
                elif ms.name == "balanced_accuracy":
                    value = 0.5 * (conf[0] + (1.0 - conf[1]))
                elif ms.name == "true_positive_rate":
                    value = conf[0]
                elif ms.name == "false_positive_rate":
                    value = conf[1]
                else:
                    value = None
            rows.append(
                MetricValue(
                    run_id=run_id,
                    record_id=None,
                    estimator_name=es.name,
                    metric_name=ms.name,
                    value=value,
                    stratum={"level": "balanced_global"},
                    metadata={**meta_base, "threshold": threshold},
                )
            )
    return rows


def _valid_point(est: EstimateResult | None) -> float | None:
    if est is None or not est.valid or est.point is None:
        return None
    return float(est.point)


def _population_std(vals: Sequence[float]) -> float:
    if not vals:
        return 0.0
    mean = sum(vals) / len(vals)
    return sqrt(sum((x - mean) ** 2 for x in vals) / len(vals))


def _mean_abs_pairwise(vals: Sequence[float]) -> float:
    pairs = list(combinations(vals, 2))
    if not pairs:
        return 0.0
    return float(sum(abs(a - b) for a, b in pairs) / len(pairs))


def _metric_aggregate_value(metric_name: str, vals: Sequence[float]) -> float:
    if metric_name == "rmse":
        return float((sum(vals) / len(vals)) ** 0.5)
    return float(sum(vals) / len(vals))


def _percentile_interval(samples: Sequence[float], level: float) -> tuple[float, float]:
    arr = np.asarray(samples, dtype=float)
    tail = (1.0 - float(level)) / 2.0
    return (float(np.quantile(arr, tail)), float(np.quantile(arr, 1.0 - tail)))


class GroundTruthEvaluator(BaseEvaluator):
    """Truth-backed metrics (ground truth + stress_test) and paired stress diagnostics."""

    def evaluate(
        self,
        manifest: BenchmarkManifest,
        records: Sequence[SeriesRecord],
        estimates: Sequence[EstimateResult],
    ) -> MetricBundle:
        if manifest.mode not in (BenchmarkMode.GROUND_TRUTH, BenchmarkMode.STRESS_TEST):
            raise ValueError(f"GroundTruthEvaluator does not support mode {manifest.mode.value!r}")
        idx = _index_estimates(estimates)
        records_by_id = {record.record_id: record for record in records}
        per_series: list[MetricValue] = []
        run_id = manifest.manifest_id

        for rec in records:
            for es in manifest.estimator_specs:
                est = idx.get((rec.record_id, es.name))
                if est is None and not (
                    manifest.mode is BenchmarkMode.STRESS_TEST
                    and rec.annotations.get("stress_role") == "contaminated"
                ):
                    continue
                try:
                    validate_truth_compatibility(es, rec)
                    compatible = True
                except ManifestValidationError:
                    compatible = False
                sk = stratum_key(rec)
                stratum_dict: dict[str, Any] = dict(stratum_from_record(rec))

                for ms in manifest.metric_specs:
                    validate_metric_admissibility(ms, manifest.mode, rec)
                    # Route by estimand kind: classification metrics (roc_auc, ...)
                    # are aggregate-only (see _classification_rows); regression
                    # truth-metrics do not apply to decision estimands like lrd_class.
                    if not _metric_applies_per_series(ms, es.target_estimand):
                        continue
                    if ms.name in STRESS_PAIR_METRICS:
                        if manifest.mode is not BenchmarkMode.STRESS_TEST:
                            continue
                        if rec.annotations.get("stress_role") != "contaminated":
                            continue
                        for row in self._stress_pair_rows(
                            run_id=run_id,
                            record=rec,
                            estimator_spec=es,
                            est=est,
                            ms=ms,
                            stratum_dict=stratum_dict,
                            sk=sk,
                            idx=idx,
                        ):
                            per_series.append(row)
                        continue
                    if est is None:
                        continue
                    if ms.name in CORRECTION_PAIR_METRICS:
                        for row in self._correction_pair_rows(
                            run_id=run_id,
                            records_by_id=records_by_id,
                            record=rec,
                            estimator_spec=es,
                            est=est,
                            ms=ms,
                            stratum_dict=stratum_dict,
                            sk=sk,
                            idx=idx,
                        ):
                            per_series.append(row)
                        continue
                    if ms.name in ("bias", "mae", "rmse") and not compatible:
                        continue
                    if ms.name == "coverage_error":
                        continue
                    for row in self._per_series_rows(
                        run_id=run_id,
                        record=rec,
                        estimator_spec=es,
                        est=est,
                        ms=ms,
                        stratum_dict=stratum_dict,
                        sk=sk,
                        compatible=compatible,
                    ):
                        per_series.append(row)

            sk = stratum_key(rec)
            stratum_dict = dict(stratum_from_record(rec))
            for ms in manifest.metric_specs:
                if ms.name in DISAGREEMENT_METRICS or ms.name in SENSITIVITY_METRICS:
                    validate_metric_admissibility(ms, manifest.mode, rec)
            per_series.extend(
                self._estimator_disagreement_rows(
                    run_id=run_id,
                    record=rec,
                    metric_specs=manifest.metric_specs,
                    estimator_specs=manifest.estimator_specs,
                    idx=idx,
                    stratum_dict=stratum_dict,
                    sk=sk,
                )
            )
            per_series.extend(
                self._parameter_variant_sensitivity_rows(
                    run_id=run_id,
                    record=rec,
                    metric_specs=manifest.metric_specs,
                    estimator_specs=manifest.estimator_specs,
                    idx=idx,
                    stratum_dict=stratum_dict,
                    sk=sk,
                )
            )

        aggregate = list(self._aggregate(run_id, per_series, manifest))
        aggregate.extend(_classification_metric_rows(run_id, records, idx, manifest))
        uncertainty = self._benchmark_uncertainty(run_id, per_series, aggregate, manifest)
        return MetricBundle(
            per_series=tuple(per_series),
            aggregate=tuple(aggregate),
            uncertainty=tuple(uncertainty),
            metadata={},
        )

    def _stress_pair_rows(
        self,
        *,
        run_id: str,
        record: SeriesRecord,
        estimator_spec: EstimatorSpec,
        est: EstimateResult | None,
        ms: MetricSpec,
        stratum_dict: dict[str, Any],
        sk: tuple[tuple[str, Any], ...],
        idx: dict[tuple[str, str], EstimateResult],
    ) -> list[MetricValue]:
        clean_id = record.annotations.get("clean_record_id")
        clean_estimate = (
            idx.get((clean_id, estimator_spec.name)) if isinstance(clean_id, str) else None
        )
        return stress_pair_rows(
            run_id=run_id,
            record=record,
            estimator_spec=estimator_spec,
            est=est,
            clean_estimate=clean_estimate,
            ms=ms,
            stratum=stratum_dict,
            stratum_key=sk,
            interval=_ci_interval,
        )

    def _correction_pair_rows(
        self,
        *,
        run_id: str,
        records_by_id: dict[str, SeriesRecord],
        record: SeriesRecord,
        estimator_spec: EstimatorSpec,
        est: EstimateResult,
        ms: MetricSpec,
        stratum_dict: dict[str, Any],
        sk: tuple[tuple[str, Any], ...],
        idx: dict[tuple[str, str], EstimateResult],
    ) -> list[MetricValue]:
        if record.annotations.get("preprocessing_role") != "corrected":
            return []
        raw_id = record.annotations.get("raw_record_id")
        if not isinstance(raw_id, str):
            return []
        raw_est = idx.get((raw_id, estimator_spec.name))
        if raw_est is None:
            return []

        meta_base: dict[str, Any] = {
            "stratum_key": sk,
            "raw_record_id": raw_id,
            "preprocessing_operator": record.annotations.get("preprocessing_operator"),
            "preprocessing_kind": record.annotations.get("preprocessing_kind"),
            "correction_target": record.annotations.get("correction_target"),
        }

        if ms.name == "correction_drift":
            if not est.valid or est.point is None or not raw_est.valid or raw_est.point is None:
                return []
            return [
                MetricValue(
                    run_id=run_id,
                    record_id=record.record_id,
                    estimator_name=estimator_spec.name,
                    metric_name=ms.name,
                    value=abs(float(est.point) - float(raw_est.point)),
                    stratum=stratum_dict,
                    metadata=meta_base,
                )
            ]

        truth = truth_for(record, estimator_spec.target_estimand)
        if truth is None or truth.target_value is None:
            return []
        if not est.valid or est.point is None:
            return []
        y = float(truth.target_value)

        if ms.name == "correction_degradation_ratio":
            if not raw_est.valid or raw_est.point is None:
                return []
            raw_err = abs(float(raw_est.point) - y)
            if raw_err < 1e-12:
                return []
            corrected_err = abs(float(est.point) - y)
            return [
                MetricValue(
                    run_id=run_id,
                    record_id=record.record_id,
                    estimator_name=estimator_spec.name,
                    metric_name=ms.name,
                    value=corrected_err / raw_err,
                    stratum=stratum_dict,
                    metadata=meta_base,
                )
            ]

        if ms.name == "oracle_gap":
            params = dict(ms.parameters)
            if record.annotations.get("preprocessing_kind") != "empirical":
                return []
            empirical_operator = params.get("empirical_operator")
            if (
                empirical_operator is not None
                and record.annotations.get("preprocessing_operator") != empirical_operator
            ):
                return []
            empirical_target = params.get("empirical_target")
            if (
                empirical_target is not None
                and record.annotations.get("correction_target") != empirical_target
            ):
                return []
            oracle = self._find_oracle_record(record, records_by_id, params)
            if oracle is None:
                return []
            oracle_est = idx.get((oracle.record_id, estimator_spec.name))
            if oracle_est is None or not oracle_est.valid or oracle_est.point is None:
                return []
            empirical_err = abs(float(est.point) - y)
            oracle_err = abs(float(oracle_est.point) - y)
            label = params.get("label")
            metric_name = f"oracle_gap:{label}" if label else ms.name
            return [
                MetricValue(
                    run_id=run_id,
                    record_id=record.record_id,
                    estimator_name=estimator_spec.name,
                    metric_name=metric_name,
                    value=empirical_err - oracle_err,
                    stratum=stratum_dict,
                    metadata={
                        **meta_base,
                        "oracle_gap_label": label,
                        "oracle_record_id": oracle.record_id,
                        "oracle_operator": oracle.annotations.get("preprocessing_operator"),
                        "oracle_correction_target": oracle.annotations.get("correction_target"),
                    },
                )
            ]

        return []

    def _find_oracle_record(
        self,
        record: SeriesRecord,
        records_by_id: dict[str, SeriesRecord],
        params: dict[str, Any],
    ) -> SeriesRecord | None:
        group_id = record.annotations.get("pair_group_id")
        raw_id = record.annotations.get("raw_record_id")
        requested_operator = params.get("oracle_operator")
        requested_target = params.get("oracle_target")
        candidates = [
            rec
            for rec in records_by_id.values()
            if rec.annotations.get("pair_group_id") == group_id
            and rec.annotations.get("raw_record_id") == raw_id
            and rec.annotations.get("preprocessing_kind") == "oracle"
        ]
        if requested_operator is not None:
            candidates = [
                rec
                for rec in candidates
                if rec.annotations.get("preprocessing_operator") == requested_operator
            ]
        if requested_target is not None:
            candidates = [
                rec
                for rec in candidates
                if rec.annotations.get("correction_target") == requested_target
            ]
        if not candidates:
            return None
        return sorted(candidates, key=lambda rec: rec.record_id)[0]

    def _per_series_rows(
        self,
        *,
        run_id: str,
        record: SeriesRecord,
        estimator_spec: EstimatorSpec,
        est: EstimateResult,
        ms: MetricSpec,
        stratum_dict: dict[str, Any],
        sk: tuple[tuple[str, Any], ...],
        compatible: bool,
    ) -> list[MetricValue]:
        truth = truth_for(record, estimator_spec.target_estimand)
        rows: list[MetricValue] = []
        meta_base: dict[str, Any] = {"stratum_key": sk}

        if ms.name == "validity_rate":
            v = 1.0 if est.valid else 0.0
            rows.append(
                MetricValue(
                    run_id=run_id,
                    record_id=record.record_id,
                    estimator_name=estimator_spec.name,
                    metric_name=ms.name,
                    value=v,
                    stratum=stratum_dict,
                    metadata=meta_base,
                )
            )
            return rows
        if ms.name == "runtime":
            rows.append(
                MetricValue(
                    run_id=run_id,
                    record_id=record.record_id,
                    estimator_name=estimator_spec.name,
                    metric_name=ms.name,
                    value=float(est.runtime_seconds or 0.0),
                    stratum=stratum_dict,
                    metadata=meta_base,
                )
            )
            return rows
        if ms.name in ("bias", "mae", "rmse"):
            if truth is None or truth.target_value is None:
                return rows
            if not est.valid or est.point is None or not np.isfinite(est.point):
                return [
                    MetricValue(
                        run_id=run_id,
                        record_id=record.record_id,
                        estimator_name=estimator_spec.name,
                        metric_name=ms.name,
                        value=None,
                        stratum=stratum_dict,
                        metadata={**meta_base, "missing_reason": "invalid_point"},
                    )
                ]
            y = float(truth.target_value)
            yhat = float(est.point)
            err = yhat - y
            if ms.name == "bias":
                val: float | None = err
            elif ms.name == "mae":
                val = abs(err)
            else:
                val = err**2
            rows.append(
                MetricValue(
                    run_id=run_id,
                    record_id=record.record_id,
                    estimator_name=estimator_spec.name,
                    metric_name=ms.name,
                    value=val,
                    stratum=stratum_dict,
                    metadata=meta_base,
                )
            )
            return rows

        if ms.name == "coverage":
            if not compatible or truth is None or truth.target_value is None:
                return rows
            y_star = float(truth.target_value)
            for alpha in ms.nominal_levels:
                bounds = _ci_interval(est, alpha)
                if bounds is None:
                    rows.append(
                        MetricValue(
                            run_id=run_id,
                            record_id=record.record_id,
                            estimator_name=estimator_spec.name,
                            metric_name=ms.name,
                            value=None,
                            stratum=stratum_dict,
                            metadata={**meta_base, "nominal": alpha, "missing_ci": True},
                        )
                    )
                    continue
                lo, hi = bounds
                hit = 1.0 if lo <= y_star <= hi else 0.0
                rows.append(
                    MetricValue(
                        run_id=run_id,
                        record_id=record.record_id,
                        estimator_name=estimator_spec.name,
                        metric_name=ms.name,
                        value=hit,
                        stratum=stratum_dict,
                        metadata={**meta_base, "nominal": alpha},
                    )
                )
            return rows

        if ms.name == "ci_availability":
            for alpha in ms.nominal_levels:
                rows.append(
                    MetricValue(
                        run_id=run_id,
                        record_id=record.record_id,
                        estimator_name=estimator_spec.name,
                        metric_name=ms.name,
                        value=float(_ci_interval(est, alpha) is not None),
                        stratum=stratum_dict,
                        metadata={**meta_base, "nominal": alpha},
                    )
                )
            return rows

        if ms.name == "ci_width":
            for alpha in ms.nominal_levels:
                bounds = _ci_interval(est, alpha)
                if bounds is None:
                    rows.append(
                        MetricValue(
                            run_id=run_id,
                            record_id=record.record_id,
                            estimator_name=estimator_spec.name,
                            metric_name=ms.name,
                            value=None,
                            stratum=stratum_dict,
                            metadata={**meta_base, "nominal": alpha, "missing_ci": True},
                        )
                    )
                else:
                    lo, hi = bounds
                    rows.append(
                        MetricValue(
                            run_id=run_id,
                            record_id=record.record_id,
                            estimator_name=estimator_spec.name,
                            metric_name=ms.name,
                            value=float(hi - lo),
                            stratum=stratum_dict,
                            metadata={**meta_base, "nominal": alpha},
                        )
                    )
            return rows

        if ms.name in {"false_positive_lrd_rate", "persistence_exceedance_rate"}:
            if not compatible or truth is None or truth.target_value is None:
                return rows
            if not est.valid or est.point is None:
                return rows
            params = dict(ms.parameters)
            threshold = float(
                params.get(
                    "threshold",
                    _default_false_positive_threshold(estimator_spec.target_estimand),
                )
            )
            null_max = float(
                params.get(
                    "null_max",
                    _default_false_positive_null_max(estimator_spec.target_estimand),
                )
            )
            if float(truth.target_value) > null_max:
                return rows
            val = 1.0 if float(est.point) >= threshold else 0.0
            rows.append(
                MetricValue(
                    run_id=run_id,
                    record_id=record.record_id,
                    estimator_name=estimator_spec.name,
                    metric_name=ms.name,
                    value=val,
                    stratum=stratum_dict,
                    metadata={
                        **meta_base,
                        "threshold": threshold,
                        "null_max": null_max,
                        "truth_target_value": float(truth.target_value),
                        "decision_rule": "point_estimate_at_or_above_threshold",
                        "calibrated_significance_test": False,
                    },
                )
            )
            return rows

        if ms.name == "instability":
            raw = est.diagnostics.get("bootstrap_point_std")
            if raw is None:
                return rows
            rows.append(
                MetricValue(
                    run_id=run_id,
                    record_id=record.record_id,
                    estimator_name=estimator_spec.name,
                    metric_name=ms.name,
                    value=float(raw),
                    stratum=stratum_dict,
                    metadata=meta_base,
                )
            )
            return rows

        if ms.name not in METRIC_SPECS:
            raise ValueError(f"unsupported metric: {ms.name}")
        return rows

    def _estimator_disagreement_rows(
        self,
        *,
        run_id: str,
        record: SeriesRecord,
        metric_specs: Sequence[MetricSpec],
        estimator_specs: Sequence[EstimatorSpec],
        idx: dict[tuple[str, str], EstimateResult],
        stratum_dict: dict[str, Any],
        sk: tuple[tuple[str, Any], ...],
    ) -> list[MetricValue]:
        requested = {m.name: m for m in metric_specs if m.name in DISAGREEMENT_METRICS}
        if not requested:
            return []

        valid: list[tuple[EstimatorSpec, float]] = []
        missing: list[str] = []
        for es in estimator_specs:
            point = _valid_point(idx.get((record.record_id, es.name)))
            if point is None:
                missing.append(es.name)
            else:
                valid.append((es, point))

        min_estimators = min(
            int(dict(ms.parameters).get("min_estimators", 2)) for ms in requested.values()
        )
        if len(valid) < min_estimators:
            return []

        rows: list[MetricValue] = []
        meta_base: dict[str, Any] = {
            "stratum_key": sk,
            "n_estimators": len(valid),
            "estimator_names": tuple(es.name for es, _ in valid),
            "estimator_families": tuple(es.family for es, _ in valid),
        }
        if missing:
            meta_base["missing_estimator_names"] = tuple(missing)

        if "cross_estimator_dispersion" in requested:
            points = [point for _, point in valid]
            rows.append(
                MetricValue(
                    run_id=run_id,
                    record_id=record.record_id,
                    estimator_name="__all_estimators__",
                    metric_name="cross_estimator_dispersion",
                    value=_population_std(points),
                    stratum=stratum_dict,
                    metadata={**meta_base, "center": sum(points) / len(points)},
                )
            )

        if "pairwise_estimator_disagreement" in requested:
            for (es_a, point_a), (es_b, point_b) in combinations(valid, 2):
                rows.append(
                    MetricValue(
                        run_id=run_id,
                        record_id=record.record_id,
                        estimator_name=f"{es_a.name}__vs__{es_b.name}",
                        metric_name="pairwise_estimator_disagreement",
                        value=abs(point_a - point_b),
                        stratum=stratum_dict,
                        metadata={
                            **meta_base,
                            "estimator_a": es_a.name,
                            "estimator_b": es_b.name,
                            "family_a": es_a.family,
                            "family_b": es_b.family,
                        },
                    )
                )

        if "family_level_disagreement" in requested:
            by_family: dict[str, list[tuple[EstimatorSpec, float]]] = defaultdict(list)
            for es, point in valid:
                by_family[es.family].append((es, point))

            for family, family_vals in by_family.items():
                if len(family_vals) < min_estimators:
                    continue
                rows.append(
                    MetricValue(
                        run_id=run_id,
                        record_id=record.record_id,
                        estimator_name=f"family:{family}",
                        metric_name="family_level_disagreement",
                        value=_mean_abs_pairwise([point for _, point in family_vals]),
                        stratum=stratum_dict,
                        metadata={
                            **meta_base,
                            "comparison_scope": "within_family",
                            "family": family,
                            "family_estimator_names": tuple(es.name for es, _ in family_vals),
                        },
                    )
                )

            for family_a, family_b in combinations(sorted(by_family), 2):
                vals_a = by_family[family_a]
                vals_b = by_family[family_b]
                disagreements = [
                    abs(point_a - point_b) for _, point_a in vals_a for _, point_b in vals_b
                ]
                rows.append(
                    MetricValue(
                        run_id=run_id,
                        record_id=record.record_id,
                        estimator_name=f"family:{family_a}__vs__{family_b}",
                        metric_name="family_level_disagreement",
                        value=float(sum(disagreements) / len(disagreements)),
                        stratum=stratum_dict,
                        metadata={
                            **meta_base,
                            "comparison_scope": "between_family",
                            "family_a": family_a,
                            "family_b": family_b,
                            "family_a_estimator_names": tuple(es.name for es, _ in vals_a),
                            "family_b_estimator_names": tuple(es.name for es, _ in vals_b),
                        },
                    )
                )

        return rows

    def _parameter_variant_sensitivity_rows(
        self,
        *,
        run_id: str,
        record: SeriesRecord,
        metric_specs: Sequence[MetricSpec],
        estimator_specs: Sequence[EstimatorSpec],
        idx: dict[tuple[str, str], EstimateResult],
        stratum_dict: dict[str, Any],
        sk: tuple[tuple[str, Any], ...],
    ) -> list[MetricValue]:
        requested = {m.name: m for m in metric_specs if m.name in SENSITIVITY_METRICS}
        if not requested:
            return []

        grouped: dict[str, list[tuple[EstimatorSpec, str, float]]] = defaultdict(list)
        for es in estimator_specs:
            params = dict(es.parameter_schema)
            base_name = params.get("_base_estimator_name")
            variant_name = params.get("_variant_name")
            if base_name is None or variant_name is None:
                continue
            point = _valid_point(idx.get((record.record_id, es.name)))
            if point is None:
                continue
            grouped[str(base_name)].append((es, str(variant_name), point))

        if not grouped:
            return []

        min_variants = min(
            int(dict(ms.parameters).get("min_variants", 2)) for ms in requested.values()
        )
        rows: list[MetricValue] = []
        for base_name, variants in sorted(grouped.items()):
            if len(variants) < min_variants:
                continue
            points = [point for _, _, point in variants]
            meta_base: dict[str, Any] = {
                "stratum_key": sk,
                "base_estimator_name": base_name,
                "n_variants": len(variants),
                "variant_estimator_names": tuple(es.name for es, _, _ in variants),
                "variant_names": tuple(name for _, name, _ in variants),
            }

            if "parameter_variant_sensitivity" in requested:
                rows.append(
                    MetricValue(
                        run_id=run_id,
                        record_id=record.record_id,
                        estimator_name=base_name,
                        metric_name="parameter_variant_sensitivity",
                        value=_population_std(points),
                        stratum=stratum_dict,
                        metadata={**meta_base, "center": sum(points) / len(points)},
                    )
                )

            if "max_variant_drift" in requested:
                drift = max(abs(a - b) for a, b in combinations(points, 2))
                rows.append(
                    MetricValue(
                        run_id=run_id,
                        record_id=record.record_id,
                        estimator_name=base_name,
                        metric_name="max_variant_drift",
                        value=float(drift),
                        stratum=stratum_dict,
                        metadata=meta_base,
                    )
                )

        return rows

    def _aggregate(
        self,
        run_id: str,
        per_series: list[MetricValue],
        manifest: BenchmarkManifest,
    ) -> list[MetricValue]:
        grouped: dict[tuple[str, str, Any, Any], list[MetricValue]] = defaultdict(list)
        ratio_rows = []
        for mv in per_series:
            if mv.metric_name == "paired_mae_ratio":
                ratio_rows.append(mv)
                continue
            sk = mv.metadata.get("stratum_key")
            if isinstance(sk, tuple):
                grouped[(mv.estimator_name, mv.metric_name, sk, mv.metadata.get("nominal"))].append(
                    mv
                )

        out: list[MetricValue] = []
        for (ename, mname, sk, nominal), group in grouped.items():
            vals = [float(m.value) for m in group if m.value is not None and np.isfinite(m.value)]
            value = _metric_aggregate_value(mname, vals) if vals else None
            meta: dict[str, Any] = {
                "aggregation": "mean_within_stratum",
                "stratum_key": sk,
                "n_attempted": len(group),
                "n_included": len(vals),
                "n_missing": len(group) - len(vals),
            }
            if nominal is not None:
                meta["nominal"] = nominal
            out.append(
                MetricValue(
                    run_id=run_id,
                    record_id=None,
                    estimator_name=ename,
                    metric_name=mname,
                    value=value,
                    stratum=dict(group[0].stratum),
                    metadata=meta,
                )
            )

        if any(m.name == "coverage_error" for m in manifest.metric_specs):
            for mv in list(out):
                nominal = mv.metadata.get("nominal")
                if mv.metric_name == "coverage" and nominal is not None:
                    out.append(
                        replace(
                            mv,
                            metric_name="coverage_error",
                            value=abs(mv.value - float(nominal)) if mv.value is not None else None,
                            metadata={**mv.metadata, "aggregation": "coverage_error_from_coverage"},
                        )
                    )

        by_key: dict[tuple[str, str, Any], list[MetricValue]] = defaultdict(list)
        for mv in out:
            by_key[(mv.estimator_name, mv.metric_name, mv.metadata.get("nominal"))].append(mv)
        global_rows: list[MetricValue] = []
        for (ename, mname, nominal), group in by_key.items():
            values = [float(m.value) for m in group if m.value is not None]
            metadata = {
                "aggregation": "mean_over_strata",
                "n_strata_attempted": len(group),
                "n_strata_included": len(values),
                "n_attempted": sum(m.metadata["n_attempted"] for m in group),
                "n_included": sum(m.metadata["n_included"] for m in group),
                "n_missing": sum(m.metadata["n_missing"] for m in group),
            }
            if nominal is not None:
                metadata["nominal"] = nominal
            global_rows.append(
                MetricValue(
                    run_id=run_id,
                    record_id=None,
                    estimator_name=ename,
                    metric_name=mname,
                    value=float(np.mean(values)) if values else None,
                    stratum={"level": "balanced_global"},
                    metadata=metadata,
                )
            )
        if ratio_rows:
            metric = next(m for m in manifest.metric_specs if m.name == "paired_mae_ratio")
            out.extend(
                aggregate_paired_mae_ratio(
                    run_id, ratio_rows, float(metric.parameters.get("denominator_epsilon", 1e-12))
                )
            )
        return out + global_rows

    def _benchmark_uncertainty(
        self,
        run_id: str,
        per_series: list[MetricValue],
        aggregate: list[MetricValue],
        manifest: BenchmarkManifest,
    ) -> list[MetricValue]:
        spec = dict(manifest.uncertainty_spec)
        if not spec or spec.get("enabled") is False:
            return []

        validate_ratio_uncertainty({m.name for m in manifest.metric_specs}, spec)

        n_boot = int(spec.get("n_bootstrap", 200))
        levels = tuple(float(x) for x in spec.get("ci_levels", (0.95,)))
        seed = int(spec.get("seed", manifest.seed_spec.get("global_seed", 0)))
        rng = np.random.default_rng(seed)

        metric_filter = {str(x) for x in spec.get("metrics", ())}
        paired_filter = {str(x) for x in spec.get("paired_metrics", ())}

        rows: list[MetricValue] = []
        rows.extend(
            self._aggregate_bootstrap_uncertainty(
                run_id=run_id,
                per_series=per_series,
                aggregate=aggregate,
                rng=rng,
                n_boot=n_boot,
                levels=levels,
                metric_filter=metric_filter,
            )
        )
        if bool(spec.get("paired", False)):
            rows.extend(
                self._paired_difference_uncertainty(
                    run_id=run_id,
                    per_series=per_series,
                    rng=rng,
                    n_boot=n_boot,
                    levels=levels,
                    metric_filter=paired_filter or metric_filter,
                )
            )
        return rows

    def _aggregate_bootstrap_uncertainty(
        self,
        *,
        run_id: str,
        per_series: list[MetricValue],
        aggregate: list[MetricValue],
        rng: np.random.Generator,
        n_boot: int,
        levels: tuple[float, ...],
        metric_filter: set[str],
    ) -> list[MetricValue]:
        grouped: dict[tuple[str, str, Any, Any], list[float]] = defaultdict(list)
        strata: dict[tuple[str, str, Any, Any], dict[str, Any]] = {}
        for mv in per_series:
            if mv.value is None or mv.record_id is None:
                continue
            if metric_filter and mv.metric_name not in metric_filter:
                continue
            sk_t = mv.metadata.get("stratum_key")
            if not isinstance(sk_t, tuple):
                continue
            key = (mv.estimator_name, mv.metric_name, sk_t, mv.metadata.get("nominal"))
            grouped[key].append(float(mv.value))
            strata[key] = dict(mv.stratum)

        rows: list[MetricValue] = []
        for key, vals in grouped.items():
            if not vals:
                continue
            ename, metric_name, sk_t, nominal = key
            samples: list[float] = []
            values = np.asarray(vals, dtype=float)
            for _ in range(n_boot):
                idx = rng.integers(0, values.size, size=values.size)
                samples.append(_metric_aggregate_value(metric_name, values[idx].tolist()))
            point = _metric_aggregate_value(metric_name, vals)
            for level in levels:
                lo, hi = _percentile_interval(samples, level)
                metadata: dict[str, Any] = {
                    "uncertainty_type": "aggregate_bootstrap",
                    "aggregation": "bootstrap_within_stratum",
                    "stratum_key": sk_t,
                    "n_bootstrap": n_boot,
                    "n_observations": len(vals),
                    "nominal": level,
                    "ci_low": lo,
                    "ci_high": hi,
                }
                if nominal is not None:
                    metadata["metric_nominal"] = nominal
                rows.append(
                    MetricValue(
                        run_id=run_id,
                        record_id=None,
                        estimator_name=ename,
                        metric_name=metric_name,
                        value=point,
                        stratum=strata[key],
                        metadata=metadata,
                    )
                )

        global_grouped: dict[tuple[str, str, Any], list[MetricValue]] = defaultdict(list)
        for mv in aggregate:
            if mv.value is None:
                continue
            if metric_filter and mv.metric_name not in metric_filter:
                continue
            if mv.stratum.get("level") == "balanced_global":
                continue
            global_grouped[(mv.estimator_name, mv.metric_name, mv.metadata.get("nominal"))].append(
                mv
            )

        for (ename, metric_name, metric_nominal), mvs in global_grouped.items():
            values = np.asarray(
                [float(mv.value) for mv in mvs if mv.value is not None],
                dtype=float,
            )
            if values.size == 0:
                continue
            samples = []
            for _ in range(n_boot):
                idx = rng.integers(0, values.size, size=values.size)
                samples.append(float(np.mean(values[idx])))
            point = float(np.mean(values))
            for level in levels:
                lo, hi = _percentile_interval(samples, level)
                metadata = {
                    "uncertainty_type": "aggregate_bootstrap",
                    "aggregation": "bootstrap_over_strata",
                    "n_bootstrap": n_boot,
                    "n_strata": int(values.size),
                    "nominal": level,
                    "ci_low": lo,
                    "ci_high": hi,
                }
                if metric_nominal is not None:
                    metadata["metric_nominal"] = metric_nominal
                rows.append(
                    MetricValue(
                        run_id=run_id,
                        record_id=None,
                        estimator_name=ename,
                        metric_name=metric_name,
                        value=point,
                        stratum={"level": "balanced_global"},
                        metadata=metadata,
                    )
                )
        return rows

    def _paired_difference_uncertainty(
        self,
        *,
        run_id: str,
        per_series: list[MetricValue],
        rng: np.random.Generator,
        n_boot: int,
        levels: tuple[float, ...],
        metric_filter: set[str],
    ) -> list[MetricValue]:
        by_group: dict[tuple[str, Any, Any], dict[str, dict[str, MetricValue]]] = defaultdict(
            lambda: defaultdict(dict)
        )
        for mv in per_series:
            if mv.value is None or mv.record_id is None:
                continue
            if metric_filter and mv.metric_name not in metric_filter:
                continue
            sk_t = mv.metadata.get("stratum_key")
            if not isinstance(sk_t, tuple):
                continue
            by_group[(mv.metric_name, sk_t, mv.metadata.get("nominal"))][mv.record_id][
                mv.estimator_name
            ] = mv

        rows: list[MetricValue] = []
        for (metric_name, sk_t, metric_nominal), by_record in by_group.items():
            estimator_names = sorted(
                {ename for estimator_map in by_record.values() for ename in estimator_map}
            )
            for est_a, est_b in combinations(estimator_names, 2):
                diffs: list[float] = []
                stratum: dict[str, Any] | None = None
                for estimator_map in by_record.values():
                    mv_a = estimator_map.get(est_a)
                    mv_b = estimator_map.get(est_b)
                    if mv_a is None or mv_b is None or mv_a.value is None or mv_b.value is None:
                        continue
                    diffs.append(float(mv_a.value) - float(mv_b.value))
                    stratum = dict(mv_a.stratum)
                if not diffs:
                    continue
                values = np.asarray(diffs, dtype=float)
                samples = []
                for _ in range(n_boot):
                    idx = rng.integers(0, values.size, size=values.size)
                    samples.append(float(np.mean(values[idx])))
                point = float(np.mean(values))
                for level in levels:
                    lo, hi = _percentile_interval(samples, level)
                    metadata = {
                        "uncertainty_type": "paired_bootstrap_difference",
                        "aggregation": "paired_bootstrap_within_stratum",
                        "stratum_key": sk_t,
                        "estimator_a": est_a,
                        "estimator_b": est_b,
                        "n_bootstrap": n_boot,
                        "n_pairs": int(values.size),
                        "nominal": level,
                        "ci_low": lo,
                        "ci_high": hi,
                    }
                    if metric_nominal is not None:
                        metadata["metric_nominal"] = metric_nominal
                    rows.append(
                        MetricValue(
                            run_id=run_id,
                            record_id=None,
                            estimator_name=f"{est_a}__minus__{est_b}",
                            metric_name=metric_name,
                            value=point,
                            stratum=stratum or {},
                            metadata=metadata,
                        )
                    )
        return rows


class ObservationalEvaluator(GroundTruthEvaluator):
    """Observational metrics (no truth): runtime, CI width, instability, scale sensitivity proxy."""

    def __init__(self, estimators: EstimatorRegistry) -> None:
        self._estimator_registry = estimators

    def evaluate(
        self,
        manifest: BenchmarkManifest,
        records: Sequence[SeriesRecord],
        estimates: Sequence[EstimateResult],
    ) -> MetricBundle:
        if manifest.mode is not BenchmarkMode.OBSERVATIONAL:
            raise ValueError(
                f"ObservationalEvaluator does not support mode {manifest.mode.value!r}"
            )
        idx = _index_estimates(estimates)
        per_series: list[MetricValue] = []
        run_id = manifest.manifest_id

        for rec in records:
            for es in manifest.estimator_specs:
                est = idx.get((rec.record_id, es.name))
                if est is None:
                    continue
                validate_truth_compatibility(es, rec)
                compatible = True
                sk = stratum_key(rec)
                stratum_dict: dict[str, Any] = dict(stratum_from_record(rec))

                for ms in manifest.metric_specs:
                    validate_metric_admissibility(ms, manifest.mode, rec)
                    if ms.name in STRESS_PAIR_METRICS:
                        continue
                    if ms.name == "preprocessing_sensitivity":
                        for row in self._preprocessing_sensitivity_rows(
                            run_id=run_id,
                            manifest=manifest,
                            record=rec,
                            estimator_spec=es,
                            est=est,
                            ms=ms,
                            stratum_dict=stratum_dict,
                            sk=sk,
                        ):
                            per_series.append(row)
                        continue
                    if ms.name == "coverage_error":
                        continue
                    for row in self._per_series_rows(
                        run_id=run_id,
                        record=rec,
                        estimator_spec=es,
                        est=est,
                        ms=ms,
                        stratum_dict=stratum_dict,
                        sk=sk,
                        compatible=compatible,
                    ):
                        per_series.append(row)

            sk = stratum_key(rec)
            stratum_dict = dict(stratum_from_record(rec))
            for ms in manifest.metric_specs:
                if ms.name in DISAGREEMENT_METRICS or ms.name in SENSITIVITY_METRICS:
                    validate_metric_admissibility(ms, manifest.mode, rec)
            per_series.extend(
                self._estimator_disagreement_rows(
                    run_id=run_id,
                    record=rec,
                    metric_specs=manifest.metric_specs,
                    estimator_specs=manifest.estimator_specs,
                    idx=idx,
                    stratum_dict=stratum_dict,
                    sk=sk,
                )
            )
            per_series.extend(
                self._parameter_variant_sensitivity_rows(
                    run_id=run_id,
                    record=rec,
                    metric_specs=manifest.metric_specs,
                    estimator_specs=manifest.estimator_specs,
                    idx=idx,
                    stratum_dict=stratum_dict,
                    sk=sk,
                )
            )

        aggregate = list(self._aggregate(run_id, per_series, manifest))
        aggregate.extend(_classification_metric_rows(run_id, records, idx, manifest))
        uncertainty = self._benchmark_uncertainty(run_id, per_series, aggregate, manifest)
        return MetricBundle(
            per_series=tuple(per_series),
            aggregate=tuple(aggregate),
            uncertainty=tuple(uncertainty),
            metadata={},
        )

    def _preprocessing_sensitivity_rows(
        self,
        *,
        run_id: str,
        manifest: BenchmarkManifest,
        record: SeriesRecord,
        estimator_spec: EstimatorSpec,
        est: EstimateResult,
        ms: MetricSpec,
        stratum_dict: dict[str, Any],
        sk: tuple[tuple[str, Any], ...],
    ) -> list[MetricValue]:
        meta_base: dict[str, Any] = {"stratum_key": sk}
        if not est.valid or est.point is None:
            return []
        eps = float(dict(manifest.preprocessing_spec).get("sensitivity_eps", 1e-4))
        estimator_params = dict(estimator_spec.parameter_schema)
        registry_name = str(
            estimator_params.get("_base_estimator_name", estimator_spec.name)
        ).split("::", 1)[0]
        builder = self._estimator_registry.get(registry_name)
        scaled = replace(record, values=record.values * (1.0 + eps))
        est2 = builder(estimator_spec).fit(scaled)
        if not est2.valid or est2.point is None:
            return [
                MetricValue(
                    run_id=run_id,
                    record_id=record.record_id,
                    estimator_name=estimator_spec.name,
                    metric_name=ms.name,
                    value=None,
                    stratum=stratum_dict,
                    metadata={**meta_base, "missing_alt": True, "sensitivity_eps": eps},
                )
            ]
        sens = abs(float(est2.point) - float(est.point)) / max(eps, 1e-12)
        return [
            MetricValue(
                run_id=run_id,
                record_id=record.record_id,
                estimator_name=estimator_spec.name,
                metric_name=ms.name,
                value=sens,
                stratum=stratum_dict,
                metadata={**meta_base, "sensitivity_eps": eps},
            )
        ]
