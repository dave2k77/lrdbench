from __future__ import annotations

from collections.abc import Mapping
from datetime import UTC, datetime
from typing import Any

import numpy as np

from lrdbench.enums import SourceType
from lrdbench.generators._signal import simulate_arfima_zero_d_zero
from lrdbench.interfaces import BaseGenerator
from lrdbench.schema import ProvenanceRecord, SeriesRecord, TruthSpec


class ARFIMAGenerator(BaseGenerator):
    @property
    def family(self) -> str:
        return "ARFIMA"

    @property
    def version(self) -> str:
        return "0.2.0"

    def generate(
        self,
        *,
        record_id: str,
        params: Mapping[str, Any],
        seed: int | None,
        manifest_id: str | None,
    ) -> SeriesRecord:
        n = int(params["n"])
        d = float(params["d"])
        sigma = float(params.get("sigma", 1.0))
        rng = np.random.default_rng(seed)
        method = str(params.get("method", "truncated_ma"))
        x = simulate_arfima_zero_d_zero(n, d, rng, sigma=sigma, method=method)
        truth = TruthSpec(
            process_family="ARFIMA(0,d,0)",
            generating_params=dict(params),
            target_estimand="long_memory_parameter",
            target_value=d,
            notes="Stationary ARFIMA target; truncated_ma approximates its infinite filter."
            if method == "truncated_ma"
            else "Exact stationary Gaussian covariance on the sampled grid.",
        )
        additional_truths = (
            TruthSpec(
                process_family="ARFIMA(0,d,0)",
                generating_params=dict(params),
                target_estimand="lrd_class",
                target_value=1.0 if d > 0.0 else 0.0,
                notes="LRD iff d > 0 (d = 0 is the short-memory null)",
            ),
        )
        prov = ProvenanceRecord(
            record_id=record_id,
            parent_id=None,
            manifest_id=manifest_id,
            created_at=datetime.now(UTC).isoformat(),
            source_version=self.version,
            software_version=None,
            git_commit=None,
            seed=seed,
        )
        ann: dict[str, Any] = {
            "process_family": self.family,
            "n": n,
            "d": d,
            "sigma": sigma,
            "simulation_method": method,
            "ma_truncation_lag": min(10 * n, 50000) if method == "truncated_ma" else None,
            "sigma_interpretation": "innovation_standard_deviation",
            "covariance_diagonal_jitter": 0.0,
        }
        return SeriesRecord(
            record_id=record_id,
            values=x,
            time_axis=None,
            sampling_rate=None,
            source_type=SourceType.SYNTHETIC,
            source_name="ARFIMA(0,d,0)",
            truth=truth,
            additional_truths=additional_truths,
            annotations=ann,
            provenance=prov,
        )
